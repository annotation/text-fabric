"""
.. include:: ../docs/writing/greek.md
"""
