"""
.. include:: ../docs/writing/syriac.md
"""
