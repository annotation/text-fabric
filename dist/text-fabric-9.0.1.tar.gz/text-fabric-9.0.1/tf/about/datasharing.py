"""
.. include:: ../docs/about/datasharing.md
"""
