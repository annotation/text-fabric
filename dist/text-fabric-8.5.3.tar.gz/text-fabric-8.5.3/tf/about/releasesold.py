"""
.. include:: ../docs/about/releasesold.md
"""
