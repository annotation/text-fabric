"""
# Guidance for searching

*   User guide to search: `tf.about.searchusage`
*   Search API: `tf.search.search`.
*   Implementation of search: `tf.about.searchdesign`
"""
