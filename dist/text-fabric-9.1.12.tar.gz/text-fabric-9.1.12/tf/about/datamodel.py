"""
.. include:: ../docs/about/datamodel.md
"""
