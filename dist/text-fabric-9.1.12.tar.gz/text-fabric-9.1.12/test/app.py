from tf.app import use

A = use('bhsa', lgc=False, check=True)
