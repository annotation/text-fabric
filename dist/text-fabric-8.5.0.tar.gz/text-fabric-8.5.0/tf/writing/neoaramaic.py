"""
.. include:: ../docs/writing/neoaramaic.md
"""
