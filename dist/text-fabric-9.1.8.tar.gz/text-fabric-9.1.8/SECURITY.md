If you find a security vulnerability in the code of Text-Fabric,
you can responsibly disclose it to me by sending an email to
[Dirk Roorda](mailto:text.annotation@icloud.com).

I will then address and remedy the vulnerability as soon as I can,
and after having fixed it, I will report it in a new issue on Github.
I will acknowledge you in that issue unless you prefer to be anonymous.

If the vulnerability is critical, we kindly request you not to file an issue for it
yourself in order to prevent unnecessary damage.
