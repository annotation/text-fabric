# Greek characters

[Greek script in Unicode](https://en.wikipedia.org/wiki/Greek_alphabet#Greek_in_Unicode)
