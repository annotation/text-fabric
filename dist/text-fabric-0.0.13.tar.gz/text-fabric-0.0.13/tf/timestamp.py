import sys
import collections
import time


class Timestamp(object):
    def __init__(self, level=None):
        self.oneLevelRep = '   |   '
        self.timestamp = {}
        self.indent(level=level, reset=True)

    def raw_msg(self, msg, tm=True, nl=True, error=False):
        if tm:
            msgRep = '{}{:>7} {}'.format(self.levelRep, self._elapsed(), msg).replace('\n', '\n'+self.levelRep)
        else:
            msgRep = '{}{}'.format(self.levelRep, msg).replace('\n', '\n'+self.levelRep)
        channel = sys.stderr if error else sys.stdout
        channel.write('{}{}'.format(msgRep, '\n' if nl else ''))
        channel.flush()

    def info(self, msg, tm=True, nl=True): self.raw_msg(msg, tm=tm, nl=nl)
    def error(self, msg, tm=True, nl=True): self.raw_msg(msg, tm=tm, nl=nl, error=True)

    def indent(self, level=None, reset=False):
        self.level = level if level != None else 0
        self.levelRep = self.oneLevelRep * self.level
        if reset:
            self.timestamp[self.level] = time.time()

    def _elapsed(self):
        interval = time.time() - self.timestamp.setdefault(self.level, time.time())
        if interval < 10: return "{: 2.2f}s".format(interval)
        interval = int(round(interval))
        if interval < 60: return "{:>2d}s".format(interval)
        if interval < 3600: return "{:>2d}m {:>02d}s".format(interval // 60, interval % 60)
        return "{:>2d}h {:>02d}m {:>02d}s".format(interval // 3600, (interval % 3600) // 60, interval % 60)

