from time import sleep
print('hello from a subprocess')
sleep(60)
