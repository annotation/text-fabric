"""
.. include:: ../../docs/about/searchdesign.md
"""
