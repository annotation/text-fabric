"""
.. include:: ../../docs/about/displaydesign.md
"""
