"""
.. include:: ../docs/about/manual.md
"""
