from subprocess import run

print('A')
run('python3 hello.py', shell=True)
print('B')
