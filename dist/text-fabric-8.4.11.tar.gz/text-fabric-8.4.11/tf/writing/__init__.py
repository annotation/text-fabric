"""
# Writing systems support

Transliteration tables for various writing systems.
"""
