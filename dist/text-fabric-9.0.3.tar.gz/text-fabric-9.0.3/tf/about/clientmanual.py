"""
.. include:: ../docs/about/clientmanual.md
"""
