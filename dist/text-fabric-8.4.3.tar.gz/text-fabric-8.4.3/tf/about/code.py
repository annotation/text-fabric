"""
.. include:: ../../docs/about/code.md
"""
