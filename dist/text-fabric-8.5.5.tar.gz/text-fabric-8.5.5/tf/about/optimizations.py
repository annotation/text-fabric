"""
.. include:: ../docs/about/optimizations.md
"""
