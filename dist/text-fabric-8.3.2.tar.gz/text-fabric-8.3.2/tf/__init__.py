"""
.. include:: ../docs/writing/top.md
"""
