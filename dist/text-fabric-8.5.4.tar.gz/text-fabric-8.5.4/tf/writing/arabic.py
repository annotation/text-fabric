"""
.. include:: ../docs/writing/arabic.md
"""
