"""
.. include:: ../../docs/about/background.md
"""
