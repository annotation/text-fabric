"""
.. include:: ../docs/about/searchusage.md
"""
