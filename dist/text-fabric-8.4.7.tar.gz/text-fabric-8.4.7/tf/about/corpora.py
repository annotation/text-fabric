"""
.. include:: ../../docs/about/corpora.md
"""
