"""
.. include:: ../../docs/search/top.md
"""
