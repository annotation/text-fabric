"""
.. include:: ../../docs/about/browser.md
"""
