"""
.. include:: docs/main/cheatsheet.md
"""
