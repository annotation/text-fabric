"""
.. include:: ../docs/about/install.md
"""
